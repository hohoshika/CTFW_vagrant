<?php

$loader = require __DIR__ . '/../src/bootstrap.php';
$loader->add('Composer\Installers\Test', __DIR__);
