<?php

namespace Fuel\Upload {
	class Dummy {}
}


namespace {
	include './vendor/autoload.php';
}
