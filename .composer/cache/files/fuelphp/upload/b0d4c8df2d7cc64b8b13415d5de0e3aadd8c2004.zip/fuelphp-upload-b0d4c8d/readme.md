# Fuel\\Upload

[![Build Status](https://travis-ci.org/fuelphp/upload.png?branch=master)](https://travis-ci.org/fuelphp/upload)

Package for processing uploaded files.

## Synopsys

This package provides the functionality to process uploaded files at a very granular level.

## Usage

```php
// todo
```
